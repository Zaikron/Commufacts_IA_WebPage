@extends('adminlte::page')
@section('title', 'Admin')
@section('content_header')
    <h1>Pagina de administración</h1>
@stop
@section('content')
    <p>Bienvenido a la zona para el administrador del sitio</p>
@stop
@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop
@section('js')
    <script> console.log('Hi!'); </script>
@stop
