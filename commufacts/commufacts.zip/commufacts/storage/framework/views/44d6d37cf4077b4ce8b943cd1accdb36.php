<html lang="es">
    <head>
        <link rel="shortcut icon" href="<?php echo e(asset('images/general/logo.png')); ?>">
    </head>
</html>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    
<?php if(session('info')): ?>
<div class="w-full flex justify-center">
    <strong class="p-4 bg-green-600 text-white font-bold text-xl rounded-lg flex justify-center mt-4"><?php echo e(session('info')); ?></strong>
</div>
<?php endif; ?>

<div>

    <div class="justify-center items-center flex bg-gray-100 w-full">
        <div class="bg-gray-100 h-auto w-full md:w-3/4 lg:w-3/5 p-4">
            <div class="bg-white p-4 rounded-md shadow-md w-full">
                <h2 class="py-4 font-bold text-gray-800 text-2xl">Crear un hecho</h2>
                <?php echo Form::open(['route' => 'facts.store', 'method' => 'post', 'files' => true]); ?>

        
                <div class="form-group">
                    <?php echo Form::label('title', 'Título', ['class' => 'font-bold text-white w-full flex justify-center bg-orange-900']); ?>

                    <?php echo Form::text('title', null, ['class' => 'form-control w-full border-gray-300 mb-4', 'placeholder' => 'Agrega un titulo...', 'name' => 'title']); ?>

                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500"><?php echo e($message); ?></span><br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
        
                <div class="form-group">
                    <?php echo Form::label('text', 'Texto', ['class' => 'font-bold text-white w-full flex justify-center bg-orange-900']); ?>

                    <?php echo Form::textarea('text', null, ['class' => 'form-control w-full', 'placeholder' => 'Redacta tu hecho...', 'name' => 'text']); ?>

                    <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div><br>
        
                <div class="form-group">
                    <?php echo Form::label('country', 'País', ['class' => 'font-bold text-white w-full flex justify-center bg-orange-900']); ?>

                    <?php echo Form::text('country', null, ['class' => 'form-control w-full border-gray-300 mb-4', 'placeholder' => 'En que pais ocurrio...', 'name' => 'country']); ?>

                    <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500"><?php echo e($message); ?></span><br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
        
                <div class="form-group">
                    <?php echo Form::label('city', 'Ciudad', ['class' => 'font-bold text-white w-full flex justify-center bg-orange-900']); ?>

                    <?php echo Form::text('city', null, ['class' => 'form-control w-full border-gray-300 mb-4', 'placeholder' => 'En que ciudad o colonia ocurrio...', 'name' => 'city']); ?>

                    <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500"><?php echo e($message); ?></span><br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
        
                <div class="form-group">
                    <?php echo Form::label('address', 'Dirección', ['class' => 'font-bold text-white w-full flex justify-center bg-orange-900']); ?>

                    <?php echo Form::text('address', null, ['class' => 'form-control w-full border-gray-300 mb-4', 'placeholder' => 'Escribe la ubicación/dirección del hecho de forma mas especifica...', 'name' => 'address']); ?>

                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-red-500"><?php echo e($message); ?></span><br>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <?php echo Form::label('images[]', 'Imágenes (Puedes seleccionar múltiples)', ['class' => 'font-bold text-white w-full flex justify-center bg-orange-900', 'name' => 'images']); ?>

                    <?php echo Form::file('images[]', ['class' => 'form-control-file w-full border-gray-300 mb-4 p-4', 'multiple' => true, 'accept' => 'image/jpeg, image/png']); ?>

                    <?php $__errorArgs = ['images'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php $__currentLoopData = $errors->get('images'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="text-red-500"><?php echo e($message); ?></span><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>                
                
                
                <div class="flex justify-center p-4 w-full">
                    <?php echo Form::submit('Publicar', ['class' => 'btn btn-primary bg-gray-800 text-white py-2 px-4 rounded-full text-lg mt-2 font-bold', 'style' => 'cursor: pointer;']); ?>

                </div>
        
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>

</div>


<script src="https://cdn.ckeditor.com/ckeditor5/40.0.0/classic/ckeditor.js"></script>


<script>
    ClassicEditor
        .create( document.querySelector( '#text' ) )
        .catch( error => {
            console.error( error );
    } );

</script>




    

    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\commufacts\resources\views/facts/create.blade.php ENDPATH**/ ?>