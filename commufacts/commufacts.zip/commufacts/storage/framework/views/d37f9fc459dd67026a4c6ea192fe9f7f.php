
<?php $__env->startSection('title', 'Administrador'); ?>
<?php $__env->startSection('content_header'); ?>
    <h1>Hechos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    
    <?php if(session('info')): ?>
    <div class="alert alert-success">
        <strong><?php echo e(session('info')); ?></strong>
    </div>
    <?php endif; ?>

    <div class="card">
        

        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <th>Titulo</th>
                    <th>Tipo</th>
                    <th>Estado</th>
                    <th colspan="2"></th>
                </thead>

                <tbody>
                    <?php $__currentLoopData = $facts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><a href="<?php echo e(route('facts.show', $fact),); ?>" target="_blank"><?php echo e($fact->title); ?></a></td>
                            <td><?php echo e($fact->type); ?></td>
                            <td><?php echo e($fact->state); ?></td>

                            <td width="10px">
                                <?php echo Form::open(['route' => ['admin.facts.update', $fact], 'method' => 'PUT']); ?>

                                <?php echo Form::hidden('state', 'Aceptado'); ?>

                                <?php echo Form::submit('Aceptar', ['class' => 'btn btn-primary btn-sm']); ?>

                                <?php echo Form::close(); ?>

                            </td>

                            <td width="10px">
                                <?php echo Form::open(['route' => ['admin.facts.update', $fact], 'method' => 'PUT']); ?>

                                <?php echo Form::hidden('state', 'Denegado'); ?>

                                <?php echo Form::submit('Rechazar', ['class' => 'btn btn-danger btn-sm']); ?>

                                <?php echo Form::close(); ?>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\commufacts\resources\views/admin/facts/index.blade.php ENDPATH**/ ?>