<html lang="es">
    <head>
        <link rel="shortcut icon" href="<?php echo e(asset('images/general/logo.png')); ?>">
    </head>
</html>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="justify-center items-center flex bg-gray-100">
        <div class="place-items-stretch bg-gray-100 h-auto w-full md:w-11/12 lg:w-3/4 justify-center items-center flex">
            <div class="grid grid-cols-5 w-full mt-2 text-xs md:text-sm lg:text-md">
                <div class="justify-center items-center flex">
                    <?php echo Form::open(['route' => 'facts.index', 'method' => 'get', 'class' => 'justify-center items-center flex w-full h-full']); ?>

                        <?php echo Form::hidden('type', 'Fantastico'); ?>

                        <?php echo Form::button('Fantastico', ['type' => 'submit', 'class' => 'w-full h-full bg-gray-50 font-bold text-gray-800 border-2 border-gray-300 border-t-transparent']); ?>

                    <?php echo Form::close(); ?>

                </div>
                <div class="justify-center items-center flex">
                    <?php echo Form::open(['route' => 'facts.index', 'method' => 'get', 'class' => 'justify-center items-center flex w-full h-full']); ?>

                        <?php echo Form::hidden('type', 'Tragico'); ?>

                        <?php echo Form::button('Tragico', ['type' => 'submit', 'class' => 'w-full h-full bg-gray-50 font-bold text-gray-800 border-2 border-gray-300 border-t-transparent']); ?>

                    <?php echo Form::close(); ?>

                </div>
                <div class="justify-center items-center flex">
                    <?php echo Form::open(['route' => 'facts.index', 'method' => 'get', 'class' => 'justify-center items-center flex w-full h-full']); ?>

                        <?php echo Form::hidden('type', 'Emocionante'); ?>

                        <?php echo Form::button('Emocionante', ['type' => 'submit', 'class' => 'w-full h-full bg-gray-50 font-bold text-gray-800 border-2 border-gray-300 border-t-transparent']); ?>

                    <?php echo Form::close(); ?>

                </div>
                <div class="justify-center items-center flex">
                    <?php echo Form::open(['route' => 'facts.index', 'method' => 'get', 'class' => 'justify-center items-center flex w-full h-full']); ?>

                        <?php echo Form::hidden('type', 'Melancolico'); ?>

                        <?php echo Form::button('Melancolico', ['type' => 'submit', 'class' => 'w-full h-full bg-gray-50 font-bold text-gray-800 border-2 border-gray-300 border-t-transparent']); ?>

                    <?php echo Form::close(); ?>

                </div>
                <div class="justify-center items-center flex">
                    <?php echo Form::open(['route' => 'facts.index', 'method' => 'get', 'class' => 'justify-center items-center flex w-full h-full']); ?>

                        <?php echo Form::hidden('type', 'Inspirador'); ?>

                        <?php echo Form::button('Inspirador', ['type' => 'submit', 'class' => 'w-full h-full bg-gray-50 font-bold text-gray-800 border-2 border-gray-300 border-t-transparent']); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>


    <div class="justify-center items-center flex bg-gray-100 px-0 md:px-2 lg:px-8">
        <div class="place-items-stretch bg-gray-100 h-auto w-full md:w-11/12 lg:w-3/4 py-8 justify-center items-center flex">
            <?php echo Form::open(['route' => 'facts.index', 'method' => 'get', 'class' => 'w-full justify-center items-center flex']); ?>

                <?php echo Form::text('search', old('search'), ['class' => 'form-group w-1/2 h-100 rounded-full text-xs md:text-base lg:text-md', 'placeholder' => 'Busca por ubicacion, fecha o acontecimiento...']); ?>

                <?php echo Form::button('Buscar', ['type' => 'submit', 'class' => 'ml-4 py-2 px-4 bg-yellow-700 rounded-md font-bold text-white text-xs md:text-base lg:text-md']); ?>

                <?php $__errorArgs = ['search'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-red-500 ml-2"><?php echo e($message); ?></span><br>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php echo Form::close(); ?>

        </div>
    </div>

    <?php if($facts->isEmpty()): ?>
        <div class="justify-center items-center flex">
            <p class="text-lg text-gray-500">No se ha encontrado ningun hecho, prueba con otra busqueda diferente</p>
        </div>
    <?php endif; ?>

    
    <?php $__currentLoopData = $facts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="justify-center items-center flex bg-gray-100 px-2 md:px-4 lg:px-8">
            <div class="grid grid-cols-1 place-items-stretch bg-gray-100 border-b-2 h-auto w-full md:w-11/12 lg:w-3/4 py-8">
                <div class="text-gray-700 text-start px-4 py-2 m-2">
                    <p class="text-xl md:text-xl lg:text-2xl font-bold text-orange-800"><a href=" <?php echo e(route('facts.show', $fact),); ?> "><?php echo e($fact->title); ?></a></p>
                </div>
                <a href=" <?php echo e(route('facts.show', $fact),); ?> ">
                    <div class="text-gray-700 text-start bg-white shadow-md rounded-lg border-2 px-8 py-4"> 
                        
                        <div class="lg:grid lg:grid-cols-2 md:grid md:grid-cols-1 sm:grid sm:grid-cols-1">
                            <div class="grid grid-cols-1 mb-2">
                                <div>
                                    <p class="text-sm md:text-md lg:text-xl text-gray-500 px-0 md:px-4 lg:px-8">
                                        <?php echo Str::limit($fact->text, $limit = 800, '...'); ?>

                                    </p>
                                </div><br>
                                <div class="grid grid-cols-2 w-full h-full items-end px-0 md:px-4 lg:px-8">
                                    <div class="flex justify-start">
                                        <p class="text-xs md:text-base lg:text-md text-orange-800 font-bold ">
                                            <?php echo e($fact->country . ', '. $fact->city . '. ' . $fact->created_at); ?>

                                        </p>
                                    </div>
                                    <div class="flex justify-end">
                                        <p class="text-xs md:text-sm lg:text-md text-white bg-gray-700 rounded-full font-bold py-2 px-4">
                                            <?php echo e($fact->type); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="px-0 md:px-4 lg:px-8">
                                <?php if($fact->images->count() > 0): ?>
                                    <?php if(file_exists(public_path('images/facts/' . $fact->images[0]->path))): ?>
                                        <img src="<?php echo e(asset('images/facts/' . $fact->images[0]->path)); ?>" alt="Fact Image">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('images/facts/cel2.jpg')); ?>" alt="Fact Image">
                                    <?php endif; ?>


                                    
                                <?php else: ?>
                                    <p>No images available</p>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                    </div>
                </a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Muestra los enlaces de paginación -->
    <div class="justify-center items-center flex bg-gray-100 px-8">
        <div class="place-items-stretch bg-gray-100 h-auto w-full md:w-11/12 lg:w-3/4 py-8">
            <div class="mt-4">
                <?php echo e($facts->appends(['search' => request('search'), 'type' => request('type')])->links()); ?>

            </div>
        </div>
    </div>
    
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\commufacts\resources\views/facts/index.blade.php ENDPATH**/ ?>