<html lang="es">
    <head>
        <link rel="shortcut icon" href="<?php echo e(asset('images/general/logo.png')); ?>">
    </head>
</html>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="justify-center items-center flex bg-gray-100 w-full">
        <div class="grid grid-cols-1 place-items-stretch bg-gray-100 h-auto w-full md:w-11/12 lg:w-3/4 p-1 md:p-2 lg:p-4">
            
            <div class="text-gray-700 text-center px-4 py-2 m-2">
                <p class="text-xl md:text-2xl lg:text-3xl font-bold text-orange-800"><?php echo e($fact->title); ?></p>
            </div>
            <div class="grid grid-cols-2 w-full h-full items-end p-2 md:p-4 lg:p-8 bg-white">
                <div class="flex justify-start">
                    <p class="text-xs md:text-base lg:text-lg text-orange-800 font-bold ">
                        <?php echo e($fact->country . ', '. $fact->city . '. ' . $fact->created_at); ?>

                    </p>
                </div>
                <div class="flex justify-end">
                    <p class="text-xs md:text-base lg:text-lg text-white bg-gray-700 rounded-full font-bold py-2 px-4">
                        <?php echo e($fact->type); ?>

                    </p>
                </div>
            </div>
            <div class="text-gray-700 text-start bg-white px-2 md:px-2 lg:px-8 py-4"> 
                <p class="text-sm md:text-base lg:text-xl text-gray-500 inline"><?php echo $fact->text; ?></p><br><br>
            </div>
            <div class="grid grid-cols-2 bg-white p-2 md:p-4 lg:p-8">
                <?php $__currentLoopData = $fact->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="p-1 md:p-2 lg:p-4 flex justify-center items-center">
                    <a href="<?php echo e(asset('images/facts/' . $image->path)); ?>" target="_blank">

                        <?php if(file_exists(public_path('images/facts/' . $image->path))): ?>
                            <img src="<?php echo e(asset('images/facts/' . $image->path)); ?>" alt="Fact Image">
                        <?php else: ?>
                            <img src="<?php echo e(asset('images/facts/cel2.jpg')); ?>" alt="Fact Image">
                        <?php endif; ?>

                        
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="bg-white w-full p-2 md:p-4 lg:p-8 text-xs md:text-base lg:text-lg">
                <p class="text-gray-600 font-bold inline">Ubicacion exacta: </p> <p class="text-gray-400 inline"><?php echo e($fact->address); ?></p>
            </div>

            
            <div class="bg-white w-full p-2 md:p-4 lg:p-8 mt-4">
                <p class="text-base md:text-base lg:text-lg text-orange-700 font-bold py-4"><?php echo e($fact->messages->count()); ?> comentarios en total</p>
                
                <div class="w-full flex">
                    <div class="pr-4">
                        <img class="h-8 md:h-10 lg:h-15 w-8 md:w-10 lg:w-15 rounded-full my-1 mx-1 border-2 border-gray-400" src="<?php echo e(auth()->user()->profile_photo_url); ?>" alt=""> 
                    </div>

                    <div class="w-11/12">
                        <?php echo Form::open(['route' => 'messages.store', 'method' => 'POST']); ?>

                        <?php echo e(Form::text('text', null, ['id' => 'comment-input', 'class' => 'text-xs md:text-sm lg:text-base w-full border-b-gray-600 border-t-transparent border-r-transparent border-l-transparent', 'placeholder' => 'Agrega un comentario...'])); ?>

                        <div class="w-full flex justify-end py-4">
                            <?php echo e(Form::hidden('user_id', auth()->user()->id)); ?>

                            <?php echo e(Form::hidden('fact_id', $fact->id)); ?>

                            <?php echo e(Form::submit('Comentar', ['id' => 'comment-button', 'class' => 'text-xs md:text-sm lg:text-base py-2 px-4 bg-orange-800 text-white font-bold rounded-full', 'disabled' => 'true', 'style' => 'cursor: pointer;'])); ?>

                        </div>
                    <?php echo Form::close(); ?>

                    </div>

                </div><br>

                
                <?php $__currentLoopData = $fact->messages()->latest()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="w-full flex border-l-2">
                        <div class="px-1 md:px-2 lg:px-4">
                            <img class="h-7 md:h-9 lg:h-10 w-7 md:w-9 lg:w-10  rounded-full my-1 mx-1 border-2 border-gray-400" src="<?php echo e($message->users->profile_photo_url); ?>" alt=""> 
                        </div>

                        <div class="w-11/12">
                            <p class="text-sm md:text-base lg:text-lg text-gray-800 font-bold inline"><?php echo e($message->users->name); ?></p>
                            <p class="text-xs md:text-sm lg:text-base text-gray-400 font-bold inline"><?php echo e($message->created_at); ?></p>
                            <p class="text-sm md:text-base lg:text-lg text-gray-700"><?php echo e($message->message); ?> </p>
                            <p class="text-xs md:text-sm lg:text-base text-orange-700 font-bold mt-2">
                                <?php echo e($message->users->country . ', '. $message->users->city); ?>

                            </p>
                        </div>
                    </div>

                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>


    </div>


    <script>
        const commentInput = document.getElementById('comment-input');
        const commentButton = document.getElementById('comment-button');
        
        commentInput.addEventListener('input', function() {
            if (commentInput.value.trim() !== '') {
                commentButton.removeAttribute('disabled');
            } else {
                commentButton.setAttribute('disabled', 'true');
            }
        });
    </script>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\commufacts\resources\views/facts/show.blade.php ENDPATH**/ ?>